from sklearn import linear_model
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


class linear_regression:
    def __init__(self):
        # reading a execl file
        self.reg = linear_model.LinearRegression()
        self.df = pd.read_excel("homeprices.xlsx")
        self.pr = pd.read_excel("areas_prediction_prices.xlsx")

    def display_file_head(self, num):
        # displaying starting few contents of the file
        if num == 0:
            print(self.pr.head())
        elif num == 1:
            print(self.pr.head())

    def scater_plot(self):
        plt.title("Home prices according to area")
        plt.xlabel("Area")
        plt.ylabel("Price")
        plt.scatter(self.df.area, self.df.price, color='blue', marker='.')
        plt.show()

    def train_linear_model(self):
        # fit mean providing the model data so that it can be trained
        # first argument should be a 2d array
        self.reg.fit(self.df[['area']], self.df['price'])
        # now it is ready to predict the prices

    def predict(self, area):
        area_array = np.array(area).reshape(-1, 1)
        print(self.reg.predict(area_array))

    def predict_return(self, area):
        area_array = np.array(area).reshape(-1, 1)
        return self.reg.predict(area_array)

    def intercept_coef(self):
        print(f"coefficient : {self.reg.coef_}")
        print(f"intercept : {self.reg.intercept_}")

    def get_pr(self):
        return self.pr

    def plot_graph(self):
        plt.title("Home prices according to area")
        plt.xlabel("Area")
        plt.ylabel("Price")
        plt.scatter(self.df.area, self.df.price, color='blue', marker='.')
        plt.plot(self.pr.area, self.pr.prices, color='black', marker=',')
        plt.show()


a = linear_regression()
a.scater_plot()
a.train_linear_model()
a.predict(750)
a.intercept_coef()


b = linear_regression()
b.display_file_head(1)
c = a.predict_return(b.get_pr())
b.pr['prices'] = c

b.pr.to_excel("areas_prediction_prices.xlsx",index=False)

b.display_file_head(1)
b.plot_graph()

